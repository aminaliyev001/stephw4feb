﻿using DatabaseClassLibrary.Entities.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Reflection;

namespace DataAccess.Contexts;
internal class LibraryDBContext : DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        string str = new ConfigurationManager().AddJsonFile("appsettings.json").Build().GetConnectionString("first");
        optionsBuilder.UseLazyLoadingProxies().UseSqlServer(str);
        base.OnConfiguring(optionsBuilder);
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        base.OnModelCreating(modelBuilder);
    }
    public virtual DbSet<Author> Authors { get; set; }
    public virtual DbSet<Book> Books { get; set; }
    public virtual DbSet<Category> Categories { get; set; }
    public virtual DbSet<Group> Groups { get; set; }
    public virtual DbSet<S_card> S_cards { get; set; }
    public virtual DbSet<Student> Students { get; set; }
    public virtual DbSet<T_card> T_cards { get; set; }
    public virtual DbSet<Teacher> Teachers { get; set; }


}
