﻿using DataAccess.Contexts;
using DataAccess.Repositories.Abstracts;
using DatabaseClassLibrary.Entities.Abstracts;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories.Concretes;
public class BaseRepository<T>  : IBaseRepository<T> where T : BaseEntity, new()
{
    internal readonly LibraryDBContext _dbContext;
    public BaseRepository()
    {
        _dbContext = new LibraryDBContext();
    }
    public void Add(T entity)
    {
        if(entity is null)throw new Exception("Null");
        _dbContext.Set<T>().Add(entity);
    }

    public ICollection<T>? getAll()
    {
        return _dbContext?.Set<T>().ToList();
    }

    public T? getById(int id)
    {
        if (id <= 0) throw new Exception("duzgun id deil");
        var entity = _dbContext?.Set<T>().FirstOrDefault(x => x.Id == id);
        return entity;
    }

    public void save()
    {
        _dbContext?.SaveChanges();
    }

    public void Update(T entity)
    {
        if(entity is null)throw new Exception("Null");
        _dbContext.Set<T>().Update(entity);
    }
}
