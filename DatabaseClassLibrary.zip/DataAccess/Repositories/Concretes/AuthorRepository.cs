﻿using DataAccess.Repositories.Abstracts;
using DatabaseClassLibrary.Entities.Concretes;

namespace DataAccess.Repositories.Concretes;
public class AuthorRepository : BaseRepository<Author>, IAuthorRepository
{
    public ICollection<Book> getBooks(int authorid)
    {
        return _dbContext.Books.Where(a => a.IdAuthor == authorid).ToList();
    }
}
