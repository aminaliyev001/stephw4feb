﻿using DataAccess.Repositories.Abstracts;
using DatabaseClassLibrary.Entities.Concretes;

namespace DataAccess.Repositories.Concretes;
public class GroupRepository : BaseRepository<Group>, IGroupRepository
{
    public ICollection<Student> GetStudents(int groupid)
    {
        return _dbContext.Students.Where(a=> a.idGroup == groupid).ToList();
    }
}
