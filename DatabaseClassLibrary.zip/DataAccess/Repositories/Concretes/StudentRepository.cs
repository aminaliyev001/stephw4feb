﻿using DataAccess.Repositories.Abstractsl;
using DatabaseClassLibrary.Entities.Concretes;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories.Concretes;
public class StudentRepository : BaseRepository<Student>, IStudentRepository
{
    public ICollection<Book>? getIssuedBooks(int studentid)
    {
        return (ICollection<Book>?)_dbContext.S_cards.Where(s => s.StudentId == studentid).Include(b => b.Book).ToList();
    }
}
