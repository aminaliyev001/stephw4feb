﻿using DatabaseClassLibrary.Entities.Abstracts;
namespace DataAccess.Repositories.Abstracts;
public interface IBaseRepository<T> where T : BaseEntity, new()
{
    void Add(T entity);
    void Update(T entity);
    T? getById(int id);
    void save();
    ICollection<T> getAll();
}
