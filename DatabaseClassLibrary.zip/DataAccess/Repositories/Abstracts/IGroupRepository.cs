﻿using DatabaseClassLibrary.Entities.Concretes;

namespace DataAccess.Repositories.Abstracts;
public interface IGroupRepository : IBaseRepository<Group>
{
    ICollection<Student> GetStudents(int groupid);
}
