﻿using DataAccess.Repositories.Abstracts;
using DatabaseClassLibrary.Entities.Concretes;

namespace DataAccess.Repositories.Abstractsl;
public interface IStudentRepository : IBaseRepository<Student>
{
    ICollection<Book>? getIssuedBooks(int studentid);
}
