﻿using DatabaseClassLibrary.Entities.Concretes;

namespace DataAccess.Repositories.Abstracts;
public interface IAuthorRepository : IBaseRepository<Author>
{
    public ICollection<Book> getBooks(int authorid);
}
