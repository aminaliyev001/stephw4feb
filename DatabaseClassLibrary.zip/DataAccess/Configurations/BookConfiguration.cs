﻿using DatabaseClassLibrary.Entities.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccess.Configurations;
internal class BookConfiguration : IEntityTypeConfiguration<Book>
{
    public void Configure(EntityTypeBuilder<Book> builder)
    {
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).UseIdentityColumn();
        builder.Property(x => x.Name).HasMaxLength(50).IsRequired();
        builder.Property(x => x.yearPress).IsRequired();
        builder.Property(x => x.totalPages).IsRequired();
        builder.Property(x => x.IdCategory).IsRequired();
        builder.Property(x => x.IdAuthor).IsRequired();
        builder.Property(x => x.quantity).IsRequired();
    }
}
