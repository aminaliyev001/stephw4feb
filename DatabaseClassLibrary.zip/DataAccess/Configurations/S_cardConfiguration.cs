﻿using DatabaseClassLibrary.Entities.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccess.Configurations;
internal class S_cardConfiguration : IEntityTypeConfiguration<S_card>
{
    public void Configure(EntityTypeBuilder<S_card> builder)
    {
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).UseIdentityColumn();
    }
}
