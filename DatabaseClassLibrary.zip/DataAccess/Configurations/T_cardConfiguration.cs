﻿using DatabaseClassLibrary.Entities.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataAccess.Configurations;
internal class T_cardConfiguration : IEntityTypeConfiguration<T_card>
{
    public void Configure(EntityTypeBuilder<T_card> builder)
    {
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).UseIdentityColumn();
    }
}
