﻿using DatabaseClassLibrary.Entities.Concretes;
using DataAccess.Contexts;
using DataAccess.Repositories.Concretes;
using DataAccess.Repositories.Abstracts;

Console.WriteLine("AS");

AuthorRepository authorRepository = new AuthorRepository();
var aut = authorRepository.getById(1);

Console.WriteLine(aut);