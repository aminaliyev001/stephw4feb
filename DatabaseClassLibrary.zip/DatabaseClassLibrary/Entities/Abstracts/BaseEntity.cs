﻿using Microsoft.VisualBasic;
using System.Text.RegularExpressions;

namespace DatabaseClassLibrary.Entities.Abstracts;
public class BaseEntity
{
    public int Id { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime UpdatedDate { get; set; }
    public BaseEntity() { 
        CreatedDate = DateTime.Now;
    }
}
//ENTITIES

//Author
//Student
//Teacher
//Group
//Category
//Book
//S_Cart
//T_Cart

//Tam Repository istifade ederek yazilmali.Ve duz ishleyib ishlemediyini.COnsoleAPP uzerinden yoxlamalisiniz.
//Configuration-lar olmalidir. 
//COnfigurationlar daxilinde Relationlar ve O relationlarda ONDELETE verilmelidir.
//LazyLoadin aktiv olmalidir.

//BaseRepository  -> GenericRepository
//GetAll
//GetById
//Add
//Save
//Remove
//Update
//-------------------------------------------------------
//Herbir bir Table oz repositorysinde ancaq ona aid olan Xususi methodda olsun en azi iki dene
