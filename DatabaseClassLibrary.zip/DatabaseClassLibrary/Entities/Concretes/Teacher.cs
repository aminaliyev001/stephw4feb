﻿using DatabaseClassLibrary.Entities.Abstracts;

namespace DatabaseClassLibrary.Entities.Concretes;
public class Teacher : BaseEntity
{
    public string? Name { get; set; }
    public virtual ICollection<T_card>? T_Cards { get; set; }
}
