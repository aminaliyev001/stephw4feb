﻿using DatabaseClassLibrary.Entities.Abstracts;

namespace DatabaseClassLibrary.Entities.Concretes;
public class Student : BaseEntity
{
    public string? Name { get; set; }
    public string? Surname { get; set; }
    public int idGroup { get; set; }
    public virtual Group? Group { get; set; }
    public virtual ICollection<S_card>? s_Cards { get; set; }

}
