﻿using DatabaseClassLibrary.Entities.Abstracts;
namespace DatabaseClassLibrary.Entities.Concretes;
public class Group : BaseEntity
{
    public string? Name { get; set; }
    public virtual ICollection<Student>? Students { get; set; }
}
