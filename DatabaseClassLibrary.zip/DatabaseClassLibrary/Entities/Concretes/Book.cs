﻿using DatabaseClassLibrary.Entities.Abstracts;
using System.ComponentModel;

namespace DatabaseClassLibrary.Entities.Concretes;
public class Book : BaseEntity
{
    public string? Name { get; set; }
    public int totalPages { get; set; }
    public int yearPress { get; set; }
    public int IdCategory { get; set; }
    public int IdAuthor { get; set; }
    public int quantity { get; set; }
    public virtual Category? Category { get; set; }
    public virtual Author? Author { get; set; }
    public virtual ICollection<T_card>? T_cards { get; set; }
    public virtual ICollection<S_card>? S_cards { get; set; }
}
