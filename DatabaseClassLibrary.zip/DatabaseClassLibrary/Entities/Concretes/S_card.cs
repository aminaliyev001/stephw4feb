﻿using DatabaseClassLibrary.Entities.Abstracts;

namespace DatabaseClassLibrary.Entities.Concretes;
public class S_card : BaseEntity
{
    public int BookId { get; set; }
    public int StudentId { get; set; }
    public virtual Student? Student { get; set; }
    public virtual Book? Book { get; set; }
}
